package australia.pets.model.repository;

import australia.pets.model.pojo.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PetRepository extends JpaRepository<Pet, Long> {

    List<Pet> findAllByOwner_Id(long id);
    List<Pet> findAllByOwner_IdIsNull();

}
