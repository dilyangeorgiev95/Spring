package australia.pets.model.dao;

import australia.pets.model.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.*;

@Component
public class UserDAO {

    private static final String REGISTER_USER_SQL = "INSERT INTO users(username,first_name,last_name,password,age) VALUES (?,?,?,?,?);";
    private static final String SELECT_USER_BY_USERNAME = "SELECT id, username, first_name, last_name, password, age FROM users WHERE username = ?;";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void addUser(User user) throws SQLException {
        Connection connection = jdbcTemplate.getDataSource().getConnection();
        try(PreparedStatement ps = connection.prepareStatement(REGISTER_USER_SQL, Statement.RETURN_GENERATED_KEYS)){
            ps.setString(1,user.getUsername());
            ps.setString(2,user.getFirstName());
            ps.setString(3,user.getLastName());
            ps.setString(4,user.getPassword());
            ps.setInt(5,user.getAge());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            keys.next();
            user.setId(keys.getLong(1));
        }

    }

    public User getByUsername(String username) throws SQLException {
        Connection connection = jdbcTemplate.getDataSource().getConnection();
        try(PreparedStatement ps = connection.prepareStatement(SELECT_USER_BY_USERNAME)){
            ps.setString(1,username);
            ResultSet rows = ps.executeQuery();
            if(rows.next()){
                return new User(rows.getLong("id"),
                        rows.getString("username"),
                        rows.getString("first_name"),
                        rows.getString("last_name"),
                        rows.getString("password"),
                        rows.getInt("age"));
            } else {
                return null;
            }
        }
    }
}
