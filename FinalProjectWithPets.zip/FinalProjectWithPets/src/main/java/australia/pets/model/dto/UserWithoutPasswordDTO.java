package australia.pets.model.dto;

import australia.pets.model.pojo.User;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UserWithoutPasswordDTO {
    private long id;
    private String username;
    private String firstName;
    private String lastName;
    private int age;

    public UserWithoutPasswordDTO(User user){
        setId(user.getId());
        setAge(user.getAge());
        setFirstName(user.getFirstName());
        setLastName(user.getLastName());
        setUsername(user.getUsername());
    }
}
