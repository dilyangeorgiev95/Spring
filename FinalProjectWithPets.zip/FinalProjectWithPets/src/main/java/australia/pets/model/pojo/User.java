package australia.pets.model.pojo;

import australia.pets.model.dto.RegisterUserDTO;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column
    private String username;
    @Column
    private String firstName;
    @Column
    private String lastName;
    @Column
    @JsonIgnore
    private String password;
    @Column
    private int age;

    public User(RegisterUserDTO dto){
        setUsername(dto.getUsername());
        setFirstName(dto.getFirstName());
        setLastName(dto.getLastName());
        setPassword(dto.getPassword()); //TODO BCRYPT!
        setAge(dto.getAge());
    }
}
