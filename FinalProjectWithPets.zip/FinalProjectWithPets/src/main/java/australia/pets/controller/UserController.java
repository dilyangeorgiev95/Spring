package australia.pets.controller;

import australia.pets.Exceptions.AuthorizationException;
import australia.pets.Exceptions.BadRequestException;
import australia.pets.model.dao.UserDAO;
import australia.pets.model.dto.LoginUserDTO;
import australia.pets.model.dto.RegisterUserDTO;
import australia.pets.model.dto.UserWithoutPasswordDTO;
import australia.pets.model.pojo.Pet;
import australia.pets.model.pojo.User;
import australia.pets.model.repository.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.sql.SQLException;
import java.util.List;

@RestController
public class UserController extends AbstractController {

    public static final String SESSION_KEY_LOGGED_USER = "logged_users";

    @Autowired
    private UserDAO userDAO;

    @Autowired
    private PetRepository petRepository;

    @PostMapping("/users")
    public UserWithoutPasswordDTO register(@RequestBody RegisterUserDTO userDTO, HttpSession session) throws SQLException {
        //TODO validate data in userDTO
        //create user object
        User user = new User(userDTO);
        //add to DB
        userDAO.addUser(user);
        session.setAttribute(SESSION_KEY_LOGGED_USER, user);
        //return UserWithoutPassDTO
        UserWithoutPasswordDTO responseDTO = new UserWithoutPasswordDTO(user);
        return responseDTO;
    }

    @PostMapping("/users/login")
    public UserWithoutPasswordDTO login(@RequestBody LoginUserDTO userDTO, HttpSession session) throws SQLException {
        User user = userDAO.getByUsername(userDTO.getUsername());

        if(user==null){
            throw new AuthorizationException("Invalid credentials");
        } else {
            if(passwordValid(user,userDTO)){
                session.setAttribute(SESSION_KEY_LOGGED_USER, user);
                UserWithoutPasswordDTO responseDTO = new UserWithoutPasswordDTO(user);
                return responseDTO;
            } else {
                throw new BadRequestException("Invalid Request Exception");
            }
        }
    }

    @PostMapping("/users/logout")
    public void logout(HttpSession session){
        session.invalidate();
    }

    @GetMapping("/users/pets")
    public List<Pet> getPets(HttpSession session) throws SQLException {
        User user = (User) session.getAttribute(SESSION_KEY_LOGGED_USER);
        if(user==null){
            throw new AuthorizationException("You must log in first");
        }
        List<Pet> pets = petRepository.findAllByOwner_Id(user.getId());
        return pets;
    }

    private boolean passwordValid(User user, LoginUserDTO userDTO) {
        //TODO validate password
        return true;
    }
}
