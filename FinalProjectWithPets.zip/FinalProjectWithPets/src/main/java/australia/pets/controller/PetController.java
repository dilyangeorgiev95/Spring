package australia.pets.controller;

import australia.pets.Exceptions.AuthorizationException;
import australia.pets.Exceptions.BadRequestException;
import australia.pets.Exceptions.NotFoundException;
import australia.pets.model.pojo.Pet;
import australia.pets.model.pojo.User;
import australia.pets.model.repository.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@RestController
public class PetController extends AbstractController {

    @Autowired
    private PetRepository petRepository;

    @GetMapping("/pets")
    public List<Pet> getAllPets(){
        return petRepository.findAll();
    }

    @GetMapping("/pets/homeless")
    public List<Pet> getHomlessPets(){
        return petRepository.findAllByOwner_IdIsNull();
    }

    @GetMapping("/pets/{id}")
    public Pet getById(@PathVariable(name = "id") long id){
        Optional<Pet> pet = petRepository.findById(id);
        if(pet.isPresent()){
            return pet.get();
        } else {
            throw new NotFoundException("Pet not found");
        }
    }

    @PostMapping("/pets/{id}/adopt")
    public List<Pet> adoptPet(@PathVariable(name = "id") long id, HttpSession session){
        User user = (User) session.getAttribute(UserController.SESSION_KEY_LOGGED_USER);
        if(user==null){
            throw new AuthorizationException();
        }
        Optional<Pet> optinalPet = petRepository.findById(id);
        if(!optinalPet.isPresent()){
            throw new NotFoundException("Pet not found");
        }
        Pet pet = optinalPet.get();
        if(pet.getOwner()!=null) {
           throw new BadRequestException("Bad is already adopted");
        }
        pet.setOwner(user);
        petRepository.save(pet);
        return petRepository.findAllByOwner_Id(user.getId());
    }
}
