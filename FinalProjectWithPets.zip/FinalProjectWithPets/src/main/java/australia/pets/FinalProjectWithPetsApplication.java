package australia.pets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProjectWithPetsApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalProjectWithPetsApplication.class, args);
    }

}
